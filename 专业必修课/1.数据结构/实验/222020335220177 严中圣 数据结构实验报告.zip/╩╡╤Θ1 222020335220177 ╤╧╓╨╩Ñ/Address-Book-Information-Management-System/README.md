# Address-Book-Information-Management-System
An address book information management system developed by C and GTK+

OS:Ubuntu 20.04.03 LTS  
## requirements:
gcc >= 7.5.0  
GTK+ 3.24.20

## Compile
sudo apt-get install build-essential  
sudo apt-get install glade  
make

## Clear
make clean