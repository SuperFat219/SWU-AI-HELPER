#include "linklist_function.h"

/**
 *
 * @param list 链表
 * @return 链表长度
 */
int linklist_length(Linklist *list)//计算链表元素个数
{
    Linklist *p = list;
    int length = 0;
    for (; list->next != NULL;) {
        length += 1;
    }
    return length;
}

/**
 * 在链表第index（从0计数）个元素后插入新节点
 * @param list 单元链表
 * @param index 第index个节点
 * @param new_node 插入节点
 */
void insert_linklist(Linklist *list, int index, Linklist *new_node) {
    Linklist *p = list;
    for (int i = 0; i < index; i++) {
        p = p->next;
    }
    new_node->next = p->next;
    p->next = new_node;
}

/**
 * 删除链表中第index个元素
 * @param list 单元链表
 * @param index 第index个节点
 */
void delete_linklist(Linklist *list, int index) {
    Linklist *p = list;//指向链表头结点
    for (int i = 1; i < index; i++) {
        p = p->next;//指向第index-1个元素
    }
    Linklist *q = p->next;
    p->next = p->next->next;
    free(q);
}