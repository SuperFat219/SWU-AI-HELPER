# Huffman
develop a software to realize huffman encode/decode using C &amp; GTK+ 
